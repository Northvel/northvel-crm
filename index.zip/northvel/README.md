# Northvel CRM

Private automotive brokerage portal for sourcing and consigning exotic & luxury vehicles ($100k+).

## Quick Start

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@northvel.com | admin123 |
| Sourcing Partner | james@northvel.com | pass123 |
| Sourcing Partner | celeste@northvel.com | pass123 |

## Deploy

### Netlify
1. Push to GitHub
2. Connect repo in Netlify → Build command: `npm run build` → Publish dir: `dist`
3. Deploy

### Vercel
1. Push to GitHub
2. Import repo in Vercel → Framework: Vite → Deploy

## Project Structure

```
northvel-crm/
├── index.html
├── vite.config.js
├── package.json
├── vercel.json          # Vercel SPA routing
├── public/
│   ├── favicon.svg
│   └── _redirects       # Netlify SPA routing
└── src/
    ├── main.jsx
    ├── App.jsx          # Full application
    └── index.css        # All styles
```
